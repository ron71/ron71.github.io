jQuery(document).ready(function(){
	jQuery("#expand_menu").click(function(){
		jQuery("#expand_menu_content").slideToggle();
	});
});

jQuery(document).ready(function(){
	jQuery("#expand_excerpt").click(function(){
		jQuery("#expand_excerpt_content").slideToggle();
	});
});
jQuery(function() {
    jQuery( document ).tooltip({
      track: true
    });
  });
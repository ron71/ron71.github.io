<?php
 /**
  * @package WPBlink_Flatolio
  * @since 1.0
  * @modified  1.0
 */

	require( get_template_directory() . '/library/init.php' );
	
?>
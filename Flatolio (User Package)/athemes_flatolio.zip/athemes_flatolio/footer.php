            <div id="footercontainer"><!-- #footer -->
                <footer class="group">
                    <div class="footer_first">
                        <?php copyrighttext(); // COPYRIGHT INFORMATION ?>
                    </div>
                    <div class="footer_second">
                        <?php backtotop(); // BACK TO TOP BUTTON ?>
                        <?php themeinfo(); // THEME INFO BUTTON ?>
                    </div>
                </footer>
            </div><!-- /footer -->
        </div><!-- /wrapper -->
		<?php wp_footer(); // WP_FOOTER ?>
	</body>
</html>